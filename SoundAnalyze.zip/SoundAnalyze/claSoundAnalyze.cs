﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CSCore;
using CSCore.Codecs;
using CSCore.DSP;
using CSCore.SoundOut;
using CSCore.Streams;
using System.IO;

namespace CSCore_Test.SoundAnalyze
{
	public class claSoundAnalyze
	{
		/// <summary>
		/// FFT 크기
		/// </summary>
		public FftSize FFTSize
		{
			get
			{
				return (FftSize)FFTSize_int;
			}
			set
			{
				if ((int)Math.Log((int)value, 2) % 1 != 0)
					throw new ArgumentOutOfRangeException("value");

				FFTSize_int = (int)value;
				
				//최대 FFT  인덱스 설정
				m_nMaxFftIndex = FFTSize_int / 2 - 1;
				//사운드 임시 버퍼 설정
				m_byteSoundBuffer = new byte[FFTSize_int];
			}
		}
		/// <summary>
		/// FFT 크기(원본)
		/// </summary>
		public int FFTSize_int;

		/// <summary>
		/// 파일 전체 경로
		/// </summary>
		public string FileName { get; set; }

		/// <summary>
		/// 최대 FFT 인덱스
		/// </summary>
		private int m_nMaxFftIndex;

		/// <summary>
		/// 사운드 임시 버퍼
		/// </summary>
		private byte[] m_byteSoundBuffer;

		/// <summary>
		/// 한줄의 데이터 개수
		/// </summary>
		public int DataCount_OneRow { get; set; }
		/// <summary>
		/// 데이터의 인덱스
		/// </summary>
		public int RowIndex 
		{
			get
			{
				return m_nRowIndex;
			}
		}
		/// <summary>
		/// 데이터의 인덱스(원본)
		/// </summary>
		private int m_nRowIndex = 0;

		/// <summary>
		/// 현재 사운드 소스의 재생된 프래임수
		/// </summary>
		public Int64 PlayFrame 
		{
			get
			{
				return m_nPlayFrame;
			}
		}
		/// <summary>
		/// 현제 사운드 소스의 재생된 프래임수(원본)
		/// </summary>
		private int m_nPlayFrame = 0;

		public IWaveSource WaveSource;

		private const int ScaleFactorLinear = 9;
		protected const int ScaleFactorSqr = 2;
		protected const double MinDbValue = -90;
		protected const double MaxDbValue = 0;
		protected const double DbScale = (MaxDbValue - MinDbValue);

		//private int _maximumFrequency = 20000;
		private int _maximumFrequencyIndex;
		//private int _minimumFrequency = 20; //Default spectrum from 20Hz to 20kHz
		private int _minimumFrequencyIndex;

		private int[] _spectrumIndexMax;
		private int[] _spectrumLogScaleIndexMax;
		private ISpectrumProvider _spectrumProvider;

		public ISpectrumProvider SpectrumProvider
		{
			get { return _spectrumProvider; }
			set
			{
				if (value == null)
					throw new ArgumentNullException("value");
				_spectrumProvider = value;
			}
		}

		


		/// <summary>
		/// 스펙트럼 데이터 구조체
		/// </summary>
		public struct SpectrumPointData
		{
			/// <summary>
			/// 스펙트럼 인덱스
			/// </summary>
			public int SpectrumPointIndex;
			/// <summary>
			/// 값
			/// </summary>
			public double Value;
		}


		/// <summary>
		/// TimeSpan형식으로 넘어온 데이터를 DateTime형식으로 바꾸기 위한 더미
		/// </summary>
		DateTime m_dtTemp = new DateTime(0001, 01, 01);
		

		public claSoundAnalyze(FftSize fftSize
								, string sFileName
								, int nDataCount_OneRow)
		{
			FFTSize = fftSize;
			FileName = sFileName;
			DataCount_OneRow = nDataCount_OneRow;

			IWaveSource source
				= CodecFactory.Instance.GetCodec(sFileName);

			var spectrumProvider 
				= new claSoundAnalyzeProvider(source.WaveFormat.Channels
						, source.WaveFormat.SampleRate, FFTSize);

			SpectrumProvider = spectrumProvider;

			var notificationSource = new SingleBlockNotificationStream(source);
			notificationSource.SingleBlockRead += (s, a) => spectrumProvider.Add(a.Left, a.Right);
			notificationSource.SingleBlockRead += notificationSource_SingleBlockRead;


			source = notificationSource.ToWaveSource(16);
			WaveSource = source;

			UpdateFrequencyMapping();

			//소스가 초기화되면 같이 초기화 시킨다.
			//줄번호
			m_nRowIndex = 0;
			//사운드 소스의 재생초기화
			SoundPlayReset();
			
		}

		/// <summary>
		///사운드소스의 프래임이 진행되면 발생하는 이벤트
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void notificationSource_SingleBlockRead(object sender, SingleBlockReadEventArgs e)
		{
			//사운드 프래임을 1개씩 올려준다.
			++m_nPlayFrame;
		}

		/// <summary>
		/// 사운드소스 재생위치 초기화
		/// </summary>
		public void SoundPlayReset()
		{
			//재생위치 초기화
			TimeSpan tsTemp = new TimeSpan(0);
			WaveSource.SetPosition(tsTemp);
			//재생 프래임 초기화
			m_nPlayFrame = 0;
		}

		public void UpdateFrequencyMapping()
		{
			int nMinimumFrequency = 20;
			int nMaximumFrequency = 20000;

			_maximumFrequencyIndex = Math.Min(_spectrumProvider.GetFftBandIndex(nMaximumFrequency) + 1, m_nMaxFftIndex);
			_minimumFrequencyIndex = Math.Min(_spectrumProvider.GetFftBandIndex(nMinimumFrequency), m_nMaxFftIndex);

			int indexCount = _maximumFrequencyIndex - _minimumFrequencyIndex;
			double linearIndexBucketSize = Math.Round(indexCount / (double)DataCount_OneRow, 3);

			_spectrumIndexMax = _spectrumIndexMax.CheckBuffer(DataCount_OneRow, true);
			_spectrumLogScaleIndexMax = _spectrumLogScaleIndexMax.CheckBuffer(DataCount_OneRow, true);

			double maxLog = Math.Log(DataCount_OneRow, DataCount_OneRow);
			for (int i = 1; i < DataCount_OneRow; i++)
			{
				int logIndex =
					(int)((maxLog - Math.Log((DataCount_OneRow + 1) - i, (DataCount_OneRow + 1))) * indexCount) +
					_minimumFrequencyIndex;

				_spectrumIndexMax[i - 1] = _minimumFrequencyIndex + (int)(i * linearIndexBucketSize);
				_spectrumLogScaleIndexMax[i - 1] = logIndex;
			}

			if (DataCount_OneRow > 0)
			{
				_spectrumIndexMax[_spectrumIndexMax.Length - 1] =
					_spectrumLogScaleIndexMax[_spectrumLogScaleIndexMax.Length - 1] = _maximumFrequencyIndex;
			}
		}

		public DataTable SoundAnalyze()
		{
			DataTable dtReturn = new DataTable();

            if(System.IO.File.Exists(@"C:\\Analysis.txt")){
                System.IO.File.Delete(@"C:\\Analysis.txt");
            }

            StreamWriter sw = new StreamWriter("C:\\Analysis.txt", true);

			TimeSpan tsTemp;
			DataRow drTemp;
			//FFT 임시버퍼
			float[] fFFTBuffer;

			double value0 = 0, value = 0;
			double lastValue = 0;
			//데이터의 최대 길이
			double dMaxValue = 200;
			int spectrumPointIndex = 0;

			//줄인덱스 초기화
			m_nRowIndex = 0;

			//1. 테이블 세팅
			//1-1. 컬럼 세팅 - 일반정보
			dtReturn.Columns.Add(new DataColumn("index", Type.GetType("System.Int32")));

			//1-1. 컬럼 세팅 - 데이터들
			Type typeDouble = Type.GetType("System.Double");
			for (int i = 0; i < DataCount_OneRow; ++i)
			{
				dtReturn.Columns.Add(i.ToString(), typeDouble);
			}
			
			//테스트 코드
			//dtReturn.Columns.Add("Test", System.Type.GetType("System.String"));

			//2. 데이터 분석 시작

			//음악파일의 길이 구하기
			long lLength = WaveSource.Length;
			long lBytes = 0;

            long count = 0;
            long frequency = 0;
            
			while (true)
			{
				//새로운 로우 생성
				drTemp = dtReturn.NewRow();


				//2-1. 데이터가 끝났는지 확인

				//진행된 현재 바이트 구하기
				tsTemp = WaveSource.GetPosition();
				lBytes = WaveSource.GetBytes(tsTemp);

                

                

				//진행된 용량과 음악파일의 전채용량과 비교한다.
				//-1000을 해주는 것은 음악파일의 길이가 딱떨어지지 않을 때가 있기 때문이다.
				if (lLength - 1000 <= lBytes)
				{
					//진행된 바이트가 (전체길이 - 1000) 보다 크다면 분석을 끝낸다.
					break;
				}


				//2-2. 소스데이터 읽기
				//FFT 버퍼를 초기화 시킨다.
				fFFTBuffer = new float[FFTSize_int];

				//사운드 프래임을 하나 읽는다.
				WaveSource.Read(m_byteSoundBuffer, 0, FFTSize_int);
				//FFT 데이터로 변환
				SpectrumProvider.GetFftData(fFFTBuffer, this);


				//2-3. 변환된 FFT데이터를 의미 있는 수로 바꾼다.

				//인덱스
				drTemp[0] = m_nRowIndex++;

				int nColumnCount = drTemp.ItemArray.Length - DataCount_OneRow;
				spectrumPointIndex = 0;

                

				for (int i = _minimumFrequencyIndex; i <= _maximumFrequencyIndex; i++)
				{
					//'ScalingStrategy.Sqrt'방식으로 데이터를 추출 한다.
					value0 = ((Math.Sqrt(fFFTBuffer[i])) * ScaleFactorSqr) * dMaxValue;

					bool recalc = true;

					value = Math.Max(0, Math.Max(value0, value));
                                       

					//'DataCount_OneRow'에 지정된 갯수 만큼 자른다.
					while (spectrumPointIndex <= DataCount_OneRow - 1 &&
						   i == _spectrumIndexMax[spectrumPointIndex])
					{

                        if(count % 50 == 0){                            
                            if(frequency % 10 == 0){
                                sw.WriteLine((long)value);
                                frequency = 0;
                            }
                            frequency++;
                            count=0;
                        }

                        count++;

						if (!recalc)
							value = lastValue;

						if (value > dMaxValue){
                            value = dMaxValue;
                        }
							

						drTemp[nColumnCount++] = value;
                       

						lastValue = value;
						value = 0.0;
						spectrumPointIndex++;
						recalc = false;                        
					}
                    

					//value = 0;
				}


				//테스트 코드
				//drTemp[51] = PlayFrame.ToString();

				dtReturn.Rows.Add(drTemp);
			}

            

			

			//3.사운드 소스의 재생위치를 처음으로 옮긴다.
			SoundPlayReset();

            sw.Close();

			return dtReturn;
		}

		

	}
}
