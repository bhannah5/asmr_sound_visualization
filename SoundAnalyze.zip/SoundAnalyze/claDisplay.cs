﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoundAnalyze.SoundAnalyze
{
	public class claDisplay
	{
		public Bitmap RowDataToBitmap(object[] sRowData)
		{
			Bitmap bitmapReturn = new Bitmap(755, 200);

			Graphics graphics = Graphics.FromImage(bitmapReturn);
			Pen pen = new Pen(Color.Brown);
			pen.Width = 5;
			PointF point1;
			PointF point2;
			
			for (int i = 3; i < sRowData.Length; ++i)
			{

				double xCoord = (5 * i) + (6 * i) + 1 + 5 / 2;

				point1 = new PointF((float) xCoord, 200);
				point2 = new PointF((float) xCoord, 200 - (float)Convert.ToDouble(sRowData[i]) - 1);
				graphics.DrawLine(pen, point1, point2);
			}


			return bitmapReturn;
		}
	}
}
