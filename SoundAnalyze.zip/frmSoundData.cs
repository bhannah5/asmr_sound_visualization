﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using CSCore;
using CSCore.Codecs;
using CSCore.DSP;
using CSCore.SoundOut;
using CSCore.Streams;

using CSCore_Test.SoundAnalyze;
using SoundAnalyze.SoundAnalyze;

namespace SoundAnalyze
{
	public partial class frmSoundData : Form
	{
		private ISoundOut _soundOut;
		private claSoundAnalyze sbTemp;
		private claDisplay m_Display = new claDisplay();

		DataTable dtData = new DataTable();

		public frmSoundData()
		{
			InitializeComponent();	
		}

		private void openToolStripMenuItem_Click(object sender, EventArgs e)
		{
			//지금은 폼생성정에서 처리하므로 일단 코드를 넣지 않는다.

			//오픈할 파일
			OpenFileDialog ofdFile = new OpenFileDialog()
			{
				Filter = CodecFactory.SupportedFilesFilterEn,
				Title = "음악 파일을 선택해 주세요."
			};

			if (System.Windows.Forms.DialogResult.OK == ofdFile.ShowDialog())
			{
				Stop();

				//
				sbTemp
				= new claSoundAnalyze(FftSize.Fft4096
					, ofdFile.FileName
					, 50);

				//사운드 재생 설정
				_soundOut = new WasapiOut();
				_soundOut.Initialize(sbTemp.WaveSource);

				//메뉴 초기화
				timerLink.Enabled = false;
			}



		}

		private void playToolStripMenuItem_Click(object sender, EventArgs e)
		{
			_soundOut.Play();
		}
		private void pauseToolStripMenuItem_Click(object sender, EventArgs e)
		{
			_soundOut.Pause();
		}

		private void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
			Stop();
			base.OnClosing(e);
		}


		private void Stop()
		{

			if (_soundOut != null)
			{
				IWaveSource source = _soundOut.WaveSource;
				_soundOut.Stop();
				_soundOut.Dispose();

				source.Dispose();
				_soundOut = null;
			}
		}

		private void dataAnalyzeToolStripMenuItem_Click(object sender, EventArgs e)
		{
			//데이터 분석
			dtData = sbTemp.SoundAnalyze();
			dataGridView1.DataSource = dtData;

			//테스크바 설정
			trackBar1.Minimum = -(sbTemp.RowIndex - 1);
			//소스 재생위치 초기화
			sbTemp.SoundPlayReset();
		}

		private void trackBar1_Scroll(object sender, EventArgs e)
		{
			int nValue = Math.Abs(trackBar1.Value);

			//데이터 그리드 뷰의 스크롤을 이동시킨다.
			dataGridView1.FirstDisplayedScrollingRowIndex = nValue;
			//현제 인덱스를 표시 한다.
			labRowCount.Text = nValue.ToString();

			pictureBox1.Image
				= m_Display.RowDataToBitmap(dtData.Rows[nValue].ItemArray);
		}

		private void linkToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (true == timerLink.Enabled)
			{
				timerLink.Enabled = false;
			}
			else
			{
				timerLink.Enabled = true;
			}
		}

		private void timerLink_Tick(object sender, EventArgs e)
		{
			DateTime m_dtTemp = new DateTime(0001, 01, 01);

			//현재 플래이 시간 가지고 오기
			TimeSpan tsTemp = sbTemp.WaveSource.GetPosition();

			//지금 인덱스 계산
			Int64 nSoundIndex = sbTemp.PlayFrame / 1024;
			//테스크바 설정
			if (trackBar1.Minimum < -nSoundIndex)
			{
				trackBar1.Value = -(int)nSoundIndex;
				trackBar1_Scroll(null, null);
			}
		}

		

		
	}
}
